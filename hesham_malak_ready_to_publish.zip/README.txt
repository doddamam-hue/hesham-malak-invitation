HESHAM & MALAK — READY TO PUBLISH

The engagement: Friday, 27 November 2026 at 7:00 PM (Cairo time).
Venue: دار المهمات — قاعات فندق اللؤلؤة
Location: https://maps.app.goo.gl/Uo8ojLexqtMA3JSNA?g_st=ic

The opening envelope, four photo animations, event-date page, venue page,
countdown and Google Maps link are embedded in index.html.
There is NO RSVP / reservation / booking form.

PUBLISH ONLINE (FREE)
1. Open https://app.netlify.com/drop
2. Drag this ZIP archive or the unzipped website folder onto the drop zone.
3. Copy the newly generated public website link and share it with your guests.

Note: Visitors will be able to view your photos when the site is public.
Search engine indexing is discouraged via metadata, but this is not a private/password protected website.
All 4 photos are stored inside the HTML; Google Fonts and Maps links need Internet.
